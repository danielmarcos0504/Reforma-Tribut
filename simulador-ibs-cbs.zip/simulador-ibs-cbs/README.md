# Simulador IBS/CBS · Daniella Cristhie

Site estático (HTML, CSS e JavaScript puro, sem build). Powered by Cotaí.

## Estrutura

```
index.html          página do simulador
assets/             logo, favicon e ícones
vercel.json         configuração da Vercel (cache e cabeçalhos)
```

## Publicar na Vercel

**Pelo site (mais fácil):**
1. Suba esta pasta para um repositório no GitHub.
2. Na Vercel: Add New → Project → importe o repositório.
3. Framework Preset: **Other**. Build Command: vazio. Output Directory: vazio (raiz).
4. Deploy.

**Pela linha de comando:**
```
npm i -g vercel
cd simulador-ibs-cbs
vercel        # primeira publicação (pré-visualização)
vercel --prod # produção
```

## Atualizar alíquotas

As alíquotas de referência ficam no início do script em `index.html`, no objeto `PRESETS`
(`cg`, `tcu`, `teto`), no formato `[CBS, IBS]`.

Simulação orientativa (LC 214/2025, arts. 251–261). Não substitui a Calculadora de Tributos da Receita Federal.
